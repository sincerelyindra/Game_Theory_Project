# Raw data

Place the original dataset archives here without modifying filenames:
- `upctna.zip`
- `wtna.zip`

Keep this directory for immutable raw inputs only.
