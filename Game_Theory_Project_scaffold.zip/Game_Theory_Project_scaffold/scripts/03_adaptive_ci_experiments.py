"""Wrapper script for adaptive confidence-interval experiments.

Recommended source file to replace / adapt from:
- part_c_adaptive_ci_experiment.py
"""

if __name__ == "__main__":
    raise SystemExit("Replace this placeholder with the contents of part_c_adaptive_ci_experiment.py")
