"""Wrapper script for the rolling historical backtest.

Recommended source file to replace / adapt from:
- tuna_colab_backtest.py
"""

if __name__ == "__main__":
    raise SystemExit("Replace this placeholder with the contents of tuna_colab_backtest.py")
