# Backtest results

Store rolling backtest outputs in `raw/`.
Recommended additions after reruns:
- `tables/`
- `figures/`
- `window_level_metrics/`
