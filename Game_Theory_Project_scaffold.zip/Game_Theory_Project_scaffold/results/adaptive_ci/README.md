# Adaptive CI results

Store adaptive confidence-interval experiment outputs in `raw/`.
Recommended additions after reruns:
- `tables/`
- `figures/`
- `model_level_summaries/`
