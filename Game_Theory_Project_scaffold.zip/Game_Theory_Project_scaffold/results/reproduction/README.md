# Reproduction results

Store the raw result bundle from the paper-reproduction script in `raw/`.
Add extracted tables and figures in sibling folders if needed.
