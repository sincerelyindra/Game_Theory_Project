"""Parametric and empirical baseline pricing models."""
