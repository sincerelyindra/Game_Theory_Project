"""Core ambiguity-set and robust-pricing logic.

Move reusable logic from the reproduction script here when refactoring.
"""
