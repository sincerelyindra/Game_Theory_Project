"""Rolling backtest utilities.

Use this module for data cleaning, window generation, and evaluation helpers.
"""
