"""Utilities for robust quantile-based pricing experiments."""
