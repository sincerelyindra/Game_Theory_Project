"""Confidence-interval helpers and adaptive calibration rules."""
