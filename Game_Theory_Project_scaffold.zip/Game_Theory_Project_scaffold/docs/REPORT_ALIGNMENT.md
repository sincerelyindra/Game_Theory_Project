# Report-to-Repository Alignment

This note explains how the repository should mirror the structure of the report.

## Part A — Reproduction of the paper

**Report content**
- feasibility of exact vs interval quantiles
- synthetic benchmark against parametric baselines
- executable best-effort solver

**Repository mapping**
- script: `scripts/01_reproduce_paper.py`
- optional reusable logic: `src/robust_pricing/core.py`, `src/robust_pricing/baselines.py`, `src/robust_pricing/ci_utils.py`
- results: `results/reproduction/raw/results_quick.zip`

## Part B — Rolling historical backtest

**Report content**
- rolling window evaluation on scanner-style data
- ERM / linear / quadratic / logit / robust comparisons
- nearest observed future-price evaluation protocol

**Repository mapping**
- script: `scripts/02_rolling_backtest.py`
- helper logic: `src/robust_pricing/backtest_utils.py`
- data: `data/raw/upctna.zip`, `data/raw/wtna.zip`
- results: `results/backtest/raw/tuna_backtest_results(1).zip`

## Part C — Adaptive confidence-interval extension

**Report content**
- fixed 90 / 95 / 99 CI comparison
- AdaptiveFeasible rule
- AdaptiveValidated rule

**Repository mapping**
- script: `scripts/03_adaptive_ci_experiments.py`
- helper logic: `src/robust_pricing/ci_utils.py`
- results: `results/adaptive_ci/raw/part_c_quick.zip`

## Why this structure works

This layout makes it easy for a reviewer to answer four questions quickly:
1. Where is the main reproduction code?
2. Where is the backtest code and data?
3. Where is the extension code?
4. Where are the outputs that correspond to each section of the report?

That is exactly what a project repo should optimize for.
